multiplied linear and quadratic damping constants with 2
