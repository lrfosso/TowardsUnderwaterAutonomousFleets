multiplied linear and quadratic damping with 0.5
