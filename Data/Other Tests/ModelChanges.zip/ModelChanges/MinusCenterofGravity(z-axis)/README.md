set zg to -0.02
