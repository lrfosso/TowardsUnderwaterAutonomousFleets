added mass constants multiplied by 0.5
