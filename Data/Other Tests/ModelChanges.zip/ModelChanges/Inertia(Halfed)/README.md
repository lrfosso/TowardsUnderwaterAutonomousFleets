Multiplied inertia by 0.5
