multiplied added mass constants with 2
